import Header from "./Header/Header.jsx";
import Main from "./Main/Main.jsx";
import Footer from "./Footer/Footer.jsx";
import { useEffect, useState, useContext } from "react";
import { api } from "../utils/api.js";
import CurrentUserContext from "../contexts/CurrentUserContext.js";

function App() {
  const { setUser } = useContext(CurrentUserContext);
  //Efecto para obtenr datos del usuario
  useEffect(() => {
    const getUser = async () => {
      try {
        const getUser = await api.getUserInfo();
        setUser(getUser);
      } catch (error) {
        console.error(`Error getUser:`, error);
      }
    };
    getUser();
  }, []); // Array vacío = solo se ejecuta al montar
  return (
    <>
      <div className="page">
        <Header />
        <Main />
        <Footer />
      </div>
    </>
  );
}

export default App;
